tinyMCE.addI18n('vi.paste_dlg',{
text_title:"S\u1EED d\u1EE5ng CTRL+V tr\u00EAn b\u00E0n ph\u00EDm \u0111\u1EC3 d\u00E1n v\u0103n b\u1EA3n v\u00E0o c\u1EEDa s\u1ED5.",
text_linebreaks:"Gi\u1EEF ng\u1EAFt d\u00F2ng",
word_title:"S\u1EED d\u1EE5ng CTRL+V tr\u00EAn b\u00E0n ph\u00EDm \u0111\u1EC3 d\u00E1n v\u0103n b\u1EA3n v\u00E0o c\u1EEDa s\u1ED5."
});