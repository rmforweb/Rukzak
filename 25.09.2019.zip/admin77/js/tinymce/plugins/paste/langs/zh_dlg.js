tinyMCE.addI18n('zh.paste_dlg',{
text_title:"\u7528 Ctrl+V \u5C07\u5167\u5BB9\u8CBC\u4E0A\u3002",
text_linebreaks:"\u4FDD\u7559\u5206\u884C\u7B26\u865F",
word_title:"\u7528 Ctrl+V \u5C07\u5167\u5BB9\u8CBC\u4E0A\u3002"
});