tinyMCE.addI18n('ro.paste_dlg',{
text_title:"Folosi\u0163i CTRL+V pentru a lipi \u00EEn aceast\u0103 zon\u0103.",
text_linebreaks:"P\u0103streaz\u0103 separatoarele de linii.",
word_title:"Folosi\u0163i CTRL+V pentru a lipi \u00EEn aceast\u0103 zon\u0103."
});