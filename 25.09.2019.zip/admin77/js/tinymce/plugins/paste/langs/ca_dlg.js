tinyMCE.addI18n('ca.paste_dlg',{
text_title:"Amb el teclat utilitzeu CTRL+V per a enganxar el text dins la finestra.",
text_linebreaks:"Conserva els salts de l\u00EDnia",
word_title:"Amb el teclat utilitzeu CTRL+V per a enganxar el text dins la finestra."
});