tinyMCE.addI18n('is.paste_dlg',{
text_title:"Nota\u00F0u CTRL+V \u00E1 lyklabor\u00F0inu til a\u00F0 l\u00EDma textanum \u00ED ritilinn.",
text_linebreaks:"Halda endingu l\u00EDna",
word_title:"Nota\u00F0u CTRL+V \u00E1 lyklabo\u00F0rinu til a\u00F0 l\u00EDma textanum \u00ED ritilinn."
});